* ENCODING=ISO-8859-1
NAME          K5030W12.KNP
ROWS
 N  OBJROW            
 L  R0000000          
 L  IC0               
 L  IC1               
 L  IC2               
 L  IC3               
 L  IC4               
 L  IC5               
 L  IC6               
 L  IC7               
 L  IC8               
 L  IC9               
 L  IC10              
 L  IC11              
 L  IC12              
 L  IC13              
 L  IC14              
 L  IC15              
 L  IC16              
 L  IC17              
 L  IC18              
 L  IC19              
 L  IC20              
 L  IC21              
 L  IC22              
 L  IC23              
 L  IC24              
 L  IC25              
 L  IC26              
 L  IC27              
 L  IC28              
 L  IC29              
 L  interdictionBudget
COLUMNS
    C0000000            OBJROW                                  658
    C0000000            R0000000                                174
    C0000000            IC0                                       1
    C0000001            OBJROW                                  305
    C0000001            R0000000                                157
    C0000001            IC1                                       1
    C0000002            OBJROW                                  378
    C0000002            R0000000                                196
    C0000002            IC2                                       1
    C0000003            OBJROW                                   65
    C0000003            R0000000                                567
    C0000003            IC3                                       1
    C0000004            OBJROW                                 1000
    C0000004            R0000000                                786
    C0000004            IC4                                       1
    C0000005            OBJROW                                   11
    C0000005            R0000000                                673
    C0000005            IC5                                       1
    C0000006            OBJROW                                  976
    C0000006            R0000000                                808
    C0000006            IC6                                       1
    C0000007            OBJROW                                  489
    C0000007            R0000000                                211
    C0000007            IC7                                       1
    C0000008            OBJROW                                  754
    C0000008            R0000000                                 86
    C0000008            IC8                                       1
    C0000009            OBJROW                                  961
    C0000009            R0000000                                565
    C0000009            IC9                                       1
    C0000010            OBJROW                                  786
    C0000010            R0000000                                868
    C0000010            IC10                                      1
    C0000011            OBJROW                                  857
    C0000011            R0000000                                623
    C0000011            IC11                                      1
    C0000012            OBJROW                                  442
    C0000012            R0000000                                716
    C0000012            IC12                                      1
    C0000013            OBJROW                                  951
    C0000013            R0000000                                927
    C0000013            IC13                                      1
    C0000014            OBJROW                                  363
    C0000014            R0000000                                196
    C0000014            IC14                                      1
    C0000015            OBJROW                                  975
    C0000015            R0000000                                367
    C0000015            IC15                                      1
    C0000016            OBJROW                                  924
    C0000016            R0000000                                722
    C0000016            IC16                                      1
    C0000017            OBJROW                                  389
    C0000017            R0000000                                529
    C0000017            IC17                                      1
    C0000018            OBJROW                                  118
    C0000018            R0000000                                616
    C0000018            IC18                                      1
    C0000019            OBJROW                                   77
    C0000019            R0000000                                459
    C0000019            IC19                                      1
    C0000020            OBJROW                                   84
    C0000020            R0000000                                936
    C0000020            IC20                                      1
    C0000021            OBJROW                                  774
    C0000021            R0000000                                497
    C0000021            IC21                                      1
    C0000022            OBJROW                                  604
    C0000022            R0000000                                129
    C0000022            IC22                                      1
    C0000023            OBJROW                                  102
    C0000023            R0000000                                409
    C0000023            IC23                                      1
    C0000024            OBJROW                                  316
    C0000024            R0000000                                529
    C0000024            IC24                                      1
    C0000025            OBJROW                                  543
    C0000025            R0000000                                778
    C0000025            IC25                                      1
    C0000026            OBJROW                                  628
    C0000026            R0000000                                247
    C0000026            IC26                                      1
    C0000027            OBJROW                                  381
    C0000027            R0000000                                523
    C0000027            IC27                                      1
    C0000028            OBJROW                                  910
    C0000028            R0000000                                119
    C0000028            IC28                                      1
    C0000029            OBJROW                                  621
    C0000029            R0000000                                979
    C0000029            IC29                                      1
    x0                  IC0                                       1
    x0                  interdictionBudget                      796
    x1                  IC1                                       1
    x1                  interdictionBudget                      103
    x2                  IC2                                       1
    x2                  interdictionBudget                       90
    x3                  IC3                                       1
    x3                  interdictionBudget                      289
    x4                  IC4                                       1
    x4                  interdictionBudget                      482
    x5                  IC5                                       1
    x5                  interdictionBudget                       97
    x6                  IC6                                       1
    x6                  interdictionBudget                      488
    x7                  IC7                                       1
    x7                  interdictionBudget                      722
    x8                  IC8                                       1
    x8                  interdictionBudget                      400
    x9                  IC9                                       1
    x9                  interdictionBudget                      282
    x10                 IC10                                      1
    x10                 interdictionBudget                        8
    x11                 IC11                                      1
    x11                 interdictionBudget                      290
    x12                 IC12                                      1
    x12                 interdictionBudget                      529
    x13                 IC13                                      1
    x13                 interdictionBudget                      810
    x14                 IC14                                      1
    x14                 interdictionBudget                      945
    x15                 IC15                                      1
    x15                 interdictionBudget                       18
    x16                 IC16                                      1
    x16                 interdictionBudget                      577
    x17                 IC17                                      1
    x17                 interdictionBudget                      178
    x18                 IC18                                      1
    x18                 interdictionBudget                      665
    x19                 IC19                                      1
    x19                 interdictionBudget                      544
    x20                 IC20                                      1
    x20                 interdictionBudget                      714
    x21                 IC21                                      1
    x21                 interdictionBudget                      177
    x22                 IC22                                      1
    x22                 interdictionBudget                      770
    x23                 IC23                                      1
    x23                 interdictionBudget                      863
    x24                 IC24                                      1
    x24                 interdictionBudget                      236
    x25                 IC25                                      1
    x25                 interdictionBudget                      293
    x26                 IC26                                      1
    x26                 interdictionBudget                      294
    x27                 IC27                                      1
    x27                 interdictionBudget                       45
    x28                 IC28                                      1
    x28                 interdictionBudget                      460
    x29                 IC29                                      1
    x29                 interdictionBudget                      975
RHS
    rhs                 R0000000                               7696
    rhs                 IC0                                       1
    rhs                 IC1                                       1
    rhs                 IC2                                       1
    rhs                 IC3                                       1
    rhs                 IC4                                       1
    rhs                 IC5                                       1
    rhs                 IC6                                       1
    rhs                 IC7                                       1
    rhs                 IC8                                       1
    rhs                 IC9                                       1
    rhs                 IC10                                      1
    rhs                 IC11                                      1
    rhs                 IC12                                      1
    rhs                 IC13                                      1
    rhs                 IC14                                      1
    rhs                 IC15                                      1
    rhs                 IC16                                      1
    rhs                 IC17                                      1
    rhs                 IC18                                      1
    rhs                 IC19                                      1
    rhs                 IC20                                      1
    rhs                 IC21                                      1
    rhs                 IC22                                      1
    rhs                 IC23                                      1
    rhs                 IC24                                      1
    rhs                 IC25                                      1
    rhs                 IC26                                      1
    rhs                 IC27                                      1
    rhs                 IC28                                      1
    rhs                 IC29                                      1
    rhs                 interdictionBudget                     6570
BOUNDS
 LO bnd C0000000 0
 UP bnd C0000000 1
 LO bnd C0000001 0
 UP bnd C0000001 1
 LO bnd C0000002 0
 UP bnd C0000002 1
 LO bnd C0000003 0
 UP bnd C0000003 1
 LO bnd C0000004 0
 UP bnd C0000004 1
 LO bnd C0000005 0
 UP bnd C0000005 1
 LO bnd C0000006 0
 UP bnd C0000006 1
 LO bnd C0000007 0
 UP bnd C0000007 1
 LO bnd C0000008 0
 UP bnd C0000008 1
 LO bnd C0000009 0
 UP bnd C0000009 1
 LO bnd C0000010 0
 UP bnd C0000010 1
 LO bnd C0000011 0
 UP bnd C0000011 1
 LO bnd C0000012 0
 UP bnd C0000012 1
 LO bnd C0000013 0
 UP bnd C0000013 1
 LO bnd C0000014 0
 UP bnd C0000014 1
 LO bnd C0000015 0
 UP bnd C0000015 1
 LO bnd C0000016 0
 UP bnd C0000016 1
 LO bnd C0000017 0
 UP bnd C0000017 1
 LO bnd C0000018 0
 UP bnd C0000018 1
 LO bnd C0000019 0
 UP bnd C0000019 1
 LO bnd C0000020 0
 UP bnd C0000020 1
 LO bnd C0000021 0
 UP bnd C0000021 1
 LO bnd C0000022 0
 UP bnd C0000022 1
 LO bnd C0000023 0
 UP bnd C0000023 1
 LO bnd C0000024 0
 UP bnd C0000024 1
 LO bnd C0000025 0
 UP bnd C0000025 1
 LO bnd C0000026 0
 UP bnd C0000026 1
 LO bnd C0000027 0
 UP bnd C0000027 1
 LO bnd C0000028 0
 UP bnd C0000028 1
 LO bnd C0000029 0
 UP bnd C0000029 1
 UP bnd x0 1
 UP bnd x1 1
 UP bnd x2 1
 UP bnd x3 1
 UP bnd x4 1
 UP bnd x5 1
 UP bnd x6 1
 UP bnd x7 1
 UP bnd x8 1
 UP bnd x9 1
 UP bnd x10 1
 UP bnd x11 1
 UP bnd x12 1
 UP bnd x13 1
 UP bnd x14 1
 UP bnd x15 1
 UP bnd x16 1
 UP bnd x17 1
 UP bnd x18 1
 UP bnd x19 1
 UP bnd x20 1
 UP bnd x21 1
 UP bnd x22 1
 UP bnd x23 1
 UP bnd x24 1
 UP bnd x25 1
 UP bnd x26 1
 UP bnd x27 1
 UP bnd x28 1
 UP bnd x29 1
ENDATA
