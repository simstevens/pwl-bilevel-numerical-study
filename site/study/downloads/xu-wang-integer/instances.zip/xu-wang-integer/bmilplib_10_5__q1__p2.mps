* ENCODING=ISO-8859-1
NAME          bmilplib_10_5
ROWS
 N  cost    
 L  l0      
 L  l1      
 L  l2      
 L  l3      
 L  f0      
 L  f1      
 L  f2      
 L  f3      
COLUMNS
    PWL0000  'MARKER'                 'INTORG'
    x0        cost                           32
    x0        l0                              8
    x0        l1                              1
    x0        l2                              3
    x0        l3                              2
    x0        f0                              7
    x0        f1                              3
    x0        f2                              5
    x0        f3                              9
    x1        cost                          -23
    x1        l0                              5
    x1        l1                              1
    x1        l2                              4
    x1        l3                              1
    x1        f0                              6
    x1        f1                              3
    x1        f2                              3
    x1        f3                              4
    x2        cost                           13
    x2        l0                              1
    x2        l1                              8
    x2        l2                              3
    x2        l3                              6
    x2        f0                              4
    x2        f1                              3
    x2        f2                              6
    x2        f3                              8
    x3        cost                          -34
    x3        l0                             10
    x3        l1                              4
    x3        l2                              7
    x3        l3                              8
    x3        f0                              4
    x3        f1                              4
    x3        f2                              1
    x4        cost                          -24
    x4        l0                              4
    x4        l1                              7
    x4        l2                              1
    x4        l3                             10
    x4        f0                              3
    x4        f1                              3
    x4        f2                              7
    x4        f3                             10
    x5        cost                           -7
    x5        l0                              2
    x5        l1                              2
    x5        l2                              8
    x5        l3                              5
    x5        f0                             10
    x5        f1                              5
    x5        f2                              2
    x5        f3                              8
    x6        cost                           33
    x6        l0                              8
    x6        l1                              4
    x6        l2                              3
    x6        f0                              8
    x6        f1                              8
    x6        f2                              8
    x6        f3                              1
    x7        cost                          -46
    x7        l0                              7
    x7        l1                              4
    x7        l2                              4
    x7        l3                              6
    x7        f0                              7
    x7        f1                              5
    x7        f2                              2
    x7        f3                              1
    x8        cost                           24
    x8        l1                              3
    x8        l2                              8
    x8        l3                              7
    x8        f0                              9
    x8        f1                              1
    x8        f2                              1
    x8        f3                              7
    x9        cost                          -43
    x9        l0                              1
    x9        l1                              1
    x9        l2                              1
    x9        f0                              9
    x9        f1                              5
    x9        f2                              7
    x9        f3                              1
    PWL0001  'MARKER'                 'INTEND'
    y0        cost                           28
    y0        l0                              4
    y0        l1                              7
    y0        l2                              7
    y0        l3                              5
    y0        f0                             10
    y0        f1                              5
    y0        f2                              7
    y1        cost                           13
    y1        l0                              1
    y1        l1                              6
    y1        l2                              1
    y1        l3                              1
    y1        f0                              8
    y1        f1                              8
    y1        f2                              1
    y1        f3                              5
    y2        cost                           42
    y2        l0                              1
    y2        l1                              1
    y2        l2                              1
    y2        l3                              2
    y2        f0                              3
    y2        f1                              6
    y2        f2                              4
    y2        f3                              4
    y3        cost                          -14
    y3        l0                              3
    y3        l1                              3
    y3        l2                              2
    y3        l3                              2
    y3        f0                              1
    y3        f1                              2
    y3        f3                             10
    y4        cost                           32
    y4        l0                              9
    y4        l1                              7
    y4        l2                              6
    y4        l3                              2
    y4        f0                              7
    y4        f1                             10
    y4        f2                              1
    y4        f3                             10
    y5        cost                           46
    y5        l0                              2
    y5        l2                             10
    y5        l3                              7
    y5        f0                              8
    y5        f1                              6
    y5        f2                              4
    y5        f3                              2
    y6        cost                          -23
    y6        l0                              6
    y6        l1                              3
    y6        l2                              1
    y6        l3                              6
    y6        f0                              8
    y6        f1                              2
    y6        f3                              8
    y7        cost                           15
    y7        l0                             10
    y7        l1                              1
    y7        l2                              2
    y7        l3                              4
    y7        f0                              7
    y7        f1                              7
    y7        f2                              7
    y7        f3                              4
    y8        cost                          -16
    y8        l1                              7
    y8        l2                              4
    y8        l3                             10
    y8        f0                              4
    y8        f1                              8
    y8        f2                              3
    y8        f3                              8
    y9        cost                           12
    y9        l0                              4
    y9        l1                              6
    y9        l2                              1
    y9        l3                              4
    y9        f0                              8
    y9        f1                              9
    y9        f2                              5
    y9        f3                              6
RHS
    rhs       l0                             46
    rhs       l1                            106
    rhs       l2                            117
    rhs       l3                             65
    rhs       f0                            106
    rhs       f1                             54
    rhs       f2                             16
    rhs       f3                             97
BOUNDS
 UP bnd       x0                             10
 UP bnd       x1                             10
 UP bnd       x2                             10
 UP bnd       x3                             10
 UP bnd       x4                             10
 UP bnd       x5                             10
 UP bnd       x6                             10
 UP bnd       x7                             10
 UP bnd       x8                             10
 UP bnd       x9                             10
LO bnd y0 0
LO bnd y2 0
LO bnd y4 0
LO bnd y5 0
 UP PREPBOUND y0 3
 UP PREPBOUND y1 7
 UP PREPBOUND y2 5
 UP PREPBOUND y3 10
 UP PREPBOUND y4 6
 UP PREPBOUND y5 5
 UP PREPBOUND y6 13
 UP PREPBOUND y7 3
 UP PREPBOUND y8 6
 UP PREPBOUND y9 4
ENDATA
