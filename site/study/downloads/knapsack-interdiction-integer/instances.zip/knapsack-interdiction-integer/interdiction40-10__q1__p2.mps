* ENCODING=ISO-8859-1
NAME          interdiction40-10
ROWS
 N  cost    
 L  KL      
 L  KF      
 L  I0      
 L  I1      
 L  I2      
 L  I3      
 L  I4      
 L  I5      
 L  I6      
 L  I7      
 L  I8      
 L  I9      
 L  I10     
 L  I11     
 L  I12     
 L  I13     
 L  I14     
 L  I15     
 L  I16     
 L  I17     
 L  I18     
 L  I19     
 L  I20     
 L  I21     
 L  I22     
 L  I23     
 L  I24     
 L  I25     
 L  I26     
 L  I27     
 L  I28     
 L  I29     
 L  I30     
 L  I31     
 L  I32     
 L  I33     
 L  I34     
 L  I35     
 L  I36     
 L  I37     
 L  I38     
 L  I39     
COLUMNS
    PWL0000  'MARKER'                 'INTORG'
    x0        KL                             46
    x0        I0                              1
    x1        KL                             40
    x1        I1                              1
    x2        KL                             34
    x2        I2                              1
    x3        KL                             26
    x3        I3                              1
    x4        KL                              3
    x4        I4                              1
    x5        KL                             65
    x5        I5                              1
    x6        KL                             42
    x6        I6                              1
    x7        KL                             58
    x7        I7                              1
    x8        KL                              7
    x8        I8                              1
    x9        KL                             36
    x9        I9                              1
    x10       KL                             14
    x10       I10                             1
    x11       KL                             13
    x11       I11                             1
    x12       KL                             26
    x12       I12                             1
    x13       KL                             83
    x13       I13                             1
    x14       KL                             40
    x14       I14                             1
    x15       KL                             41
    x15       I15                             1
    x16       KL                             62
    x16       I16                             1
    x17       KL                             24
    x17       I17                             1
    x18       KL                              1
    x18       I18                             1
    x19       KL                             53
    x19       I19                             1
    x20       KL                             51
    x20       I20                             1
    x21       KL                             65
    x21       I21                             1
    x22       KL                             44
    x22       I22                             1
    x23       KL                             69
    x23       I23                             1
    x24       KL                             74
    x24       I24                             1
    x25       KL                             24
    x25       I25                             1
    x26       KL                             50
    x26       I26                             1
    x27       KL                             48
    x27       I27                             1
    x28       KL                             23
    x28       I28                             1
    x29       KL                             42
    x29       I29                             1
    x30       KL                             57
    x30       I30                             1
    x31       KL                             91
    x31       I31                             1
    x32       KL                             92
    x32       I32                             1
    x33       KL                             28
    x33       I33                             1
    x34       KL                             65
    x34       I34                             1
    x35       KL                              5
    x35       I35                             1
    x36       KL                              8
    x36       I36                             1
    x37       KL                             52
    x37       I37                             1
    x38       KL                             88
    x38       I38                             1
    x39       KL                             16
    x39       I39                             1
    PWL0001  'MARKER'                 'INTEND'
    y0        cost                           19
    y0        KF                              1
    y0        I0                              1
    y1        cost                           87
    y1        KF                             96
    y1        I1                              1
    y2        cost                           97
    y2        KF                             67
    y2        I2                              1
    y3        cost                           22
    y3        KF                             90
    y3        I3                              1
    y4        cost                           47
    y4        KF                             13
    y4        I4                              1
    y5        cost                           22
    y5        KF                             74
    y5        I5                              1
    y6        cost                           30
    y6        KF                             22
    y6        I6                              1
    y7        cost                            5
    y7        KF                             86
    y7        I7                              1
    y8        cost                           32
    y8        KF                             23
    y8        I8                              1
    y9        cost                           54
    y9        KF                             63
    y9        I9                              1
    y10       cost                           75
    y10       KF                             89
    y10       I10                             1
    y11       cost                           70
    y11       KF                             25
    y11       I11                             1
    y12       cost                            7
    y12       KF                            100
    y12       I12                             1
    y13       cost                           76
    y13       KF                             76
    y13       I13                             1
    y14       cost                           31
    y14       KF                             23
    y14       I14                             1
    y15       cost                           61
    y15       KF                             56
    y15       I15                             1
    y16       cost                           98
    y16       KF                              5
    y16       I16                             1
    y17       cost                           27
    y17       KF                             47
    y17       I17                             1
    y18       cost                           39
    y18       KF                             45
    y18       I18                             1
    y19       cost                           91
    y19       KF                             39
    y19       I19                             1
    y20       cost                           50
    y20       KF                             47
    y20       I20                             1
    y21       cost                           10
    y21       KF                             11
    y21       I21                             1
    y22       cost                           38
    y22       KF                            100
    y22       I22                             1
    y23       cost                           25
    y23       KF                             27
    y23       I23                             1
    y24       cost                           43
    y24       KF                             60
    y24       I24                             1
    y25       cost                           37
    y25       KF                             76
    y25       I25                             1
    y26       cost                           77
    y26       KF                             75
    y26       I26                             1
    y27       cost                           18
    y27       KF                             37
    y27       I27                             1
    y28       cost                           99
    y28       KF                              1
    y28       I28                             1
    y29       cost                            9
    y29       KF                             81
    y29       I29                             1
    y30       cost                           19
    y30       KF                             51
    y30       I30                             1
    y31       cost                           97
    y31       KF                             30
    y31       I31                             1
    y32       cost                           75
    y32       KF                             40
    y32       I32                             1
    y33       cost                           26
    y33       KF                             48
    y33       I33                             1
    y34       cost                           41
    y34       KF                             68
    y34       I34                             1
    y35       cost                           84
    y35       KF                             31
    y35       I35                             1
    y36       cost                           48
    y36       KF                             13
    y36       I36                             1
    y37       cost                           75
    y37       KF                             81
    y37       I37                             1
    y38       cost                           78
    y38       KF                             67
    y38       I38                             1
    y39       cost                           41
    y39       KF                             12
    y39       I39                             1
RHS
    rhs       KL                           1820
    rhs       KF                           1814
    rhs       I0                              1
    rhs       I1                              1
    rhs       I2                              1
    rhs       I3                              1
    rhs       I4                              1
    rhs       I5                              1
    rhs       I6                              1
    rhs       I7                              1
    rhs       I8                              1
    rhs       I9                              1
    rhs       I10                             1
    rhs       I11                             1
    rhs       I12                             1
    rhs       I13                             1
    rhs       I14                             1
    rhs       I15                             1
    rhs       I16                             1
    rhs       I17                             1
    rhs       I18                             1
    rhs       I19                             1
    rhs       I20                             1
    rhs       I21                             1
    rhs       I22                             1
    rhs       I23                             1
    rhs       I24                             1
    rhs       I25                             1
    rhs       I26                             1
    rhs       I27                             1
    rhs       I28                             1
    rhs       I29                             1
    rhs       I30                             1
    rhs       I31                             1
    rhs       I32                             1
    rhs       I33                             1
    rhs       I34                             1
    rhs       I35                             1
    rhs       I36                             1
    rhs       I37                             1
    rhs       I38                             1
    rhs       I39                             1
BOUNDS
 BV bnd       x0      
 BV bnd       x1      
 BV bnd       x2      
 BV bnd       x3      
 BV bnd       x4      
 BV bnd       x5      
 BV bnd       x6      
 BV bnd       x7      
 BV bnd       x8      
 BV bnd       x9      
 BV bnd       x10     
 BV bnd       x11     
 BV bnd       x12     
 BV bnd       x13     
 BV bnd       x14     
 BV bnd       x15     
 BV bnd       x16     
 BV bnd       x17     
 BV bnd       x18     
 BV bnd       x19     
 BV bnd       x20     
 BV bnd       x21     
 BV bnd       x22     
 BV bnd       x23     
 BV bnd       x24     
 BV bnd       x25     
 BV bnd       x26     
 BV bnd       x27     
 BV bnd       x28     
 BV bnd       x29     
 BV bnd       x30     
 BV bnd       x31     
 BV bnd       x32     
 BV bnd       x33     
 BV bnd       x34     
 BV bnd       x35     
 BV bnd       x36     
 BV bnd       x37     
 BV bnd       x38     
 BV bnd       x39     
 LO bnd y0 0
 UP bnd y0 1
 LO bnd y1 0
 UP bnd y1 1
 LO bnd y2 0
 UP bnd y2 1
 LO bnd y3 0
 UP bnd y3 1
 LO bnd y4 0
 UP bnd y4 1
 LO bnd y5 0
 UP bnd y5 1
 LO bnd y6 0
 UP bnd y6 1
 LO bnd y7 0
 UP bnd y7 1
 LO bnd y8 0
 UP bnd y8 1
 LO bnd y9 0
 UP bnd y9 1
 LO bnd y10 0
 UP bnd y10 1
 LO bnd y11 0
 UP bnd y11 1
 LO bnd y12 0
 UP bnd y12 1
 LO bnd y13 0
 UP bnd y13 1
 LO bnd y14 0
 UP bnd y14 1
 LO bnd y15 0
 UP bnd y15 1
 LO bnd y16 0
 UP bnd y16 1
 LO bnd y17 0
 UP bnd y17 1
 LO bnd y18 0
 UP bnd y18 1
 LO bnd y19 0
 UP bnd y19 1
 LO bnd y20 0
 UP bnd y20 1
 LO bnd y21 0
 UP bnd y21 1
 LO bnd y22 0
 UP bnd y22 1
 LO bnd y23 0
 UP bnd y23 1
 LO bnd y24 0
 UP bnd y24 1
 LO bnd y25 0
 UP bnd y25 1
 LO bnd y26 0
 UP bnd y26 1
 LO bnd y27 0
 UP bnd y27 1
 LO bnd y28 0
 UP bnd y28 1
 LO bnd y29 0
 UP bnd y29 1
 LO bnd y30 0
 UP bnd y30 1
 LO bnd y31 0
 UP bnd y31 1
 LO bnd y32 0
 UP bnd y32 1
 LO bnd y33 0
 UP bnd y33 1
 LO bnd y34 0
 UP bnd y34 1
 LO bnd y35 0
 UP bnd y35 1
 LO bnd y36 0
 UP bnd y36 1
 LO bnd y37 0
 UP bnd y37 1
 LO bnd y38 0
 UP bnd y38 1
 LO bnd y39 0
 UP bnd y39 1
ENDATA
